import { describe, expect, it } from 'vitest';
import { runSimulation, calculateBdpMbpsMs, longestPrefixMatch } from '../src/sim/engine';
import { scenarios } from '../src/data/scenarios';

describe('deterministic network teaching engine',()=>{
 it('replays the same seed with identical event ordering',()=>{const a=runSimulation(scenarios[0]);const b=runSimulation(scenarios[0]);expect(a.events).toEqual(b.events);});
 it('completes the baseline request',()=>{const r=runSimulation(scenarios[0]);expect(r.success).toBe(true);expect(r.events[r.events.length-1]?.type).toBe('ApplicationComplete');});
 it('surfaces a stale DNS answer before transport completion',()=>{const r=runSimulation(scenarios[3]);expect(r.success).toBe(false);expect(r.events.find(e=>e.type==='DnsResolved')).toBeTruthy();expect(r.events.some(e=>e.type==='PacketDropped')).toBe(true);});
 it('models a congested queue as additional queueing delay',()=>{const r=runSimulation(scenarios[1]);expect(r.metrics.queueDelayMs).toBeGreaterThan(0);});
 it('calculates bandwidth-delay product in decimal megabytes',()=>{expect(calculateBdpMbpsMs(100,80)).toBeCloseTo(1,5);});
 it('uses longest-prefix match over a less-specific route',()=>{const routes=[{prefix:'10.0.0.0/8',nextHop:'A'},{prefix:'10.1.0.0/16',nextHop:'B'}];expect(longestPrefixMatch('10.1.2.3',routes)?.nextHop).toBe('B');});
});
