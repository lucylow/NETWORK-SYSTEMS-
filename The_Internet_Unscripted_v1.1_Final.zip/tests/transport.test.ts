import { describe, expect, it } from 'vitest';
import { bandwidthDelayProductBytes, simulateCwnd } from '../src/sim/transport';
describe('transport teaching models',()=>{
 it('calculates BDP in bytes',()=>expect(bandwidthDelayProductBytes(100,80)).toBe(1_000_000));
 it('is deterministic for the same configuration',()=>{const c={initialCwnd:1,initialSsthresh:16,rounds:10,lossRound:6,lossKind:'timeout' as const};expect(simulateCwnd(c)).toEqual(simulateCwnd(c))});
 it('models timeout as a cwnd reset',()=>{const rows=simulateCwnd({initialCwnd:1,initialSsthresh:8,rounds:8,lossRound:4,lossKind:'timeout'});expect(rows.find(r=>r.lost)?.cwnd).toBe(1)});
 it('does not inject a loss when disabled',()=>expect(simulateCwnd({initialCwnd:1,initialSsthresh:8,rounds:8,lossRound:4,lossKind:'none'}).some(r=>r.lost)).toBe(false));
});
