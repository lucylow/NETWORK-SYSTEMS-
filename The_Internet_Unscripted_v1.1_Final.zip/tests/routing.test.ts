import { describe, expect, it } from 'vitest';
import { intToIpv4, ipv4ToInt, longestPrefixMatch, prefixMask, subnetDetails, demoRoutes } from '../src/sim/routing';
describe('IPv4 utilities',()=>{
 it('round-trips dotted decimal addresses',()=>expect(intToIpv4(ipv4ToInt('203.0.113.9'))).toBe('203.0.113.9'));
 it('rejects malformed addresses',()=>expect(()=>ipv4ToInt('300.1.2.3')).toThrow());
 it('builds a /24 mask',()=>expect(intToIpv4(prefixMask(24))).toBe('255.255.255.0'));
 it('calculates a /24 network boundary',()=>{const d=subnetDetails('192.0.2.77',24);expect(d.network).toBe('192.0.2.0');expect(d.broadcast).toBe('192.0.2.255');expect(d.usableHosts).toBe(254)});
 it('uses longest-prefix match instead of the broader route',()=>expect(longestPrefixMatch('10.1.4.25',demoRoutes)?.route.prefix).toBe(24));
 it('falls back to the default route',()=>expect(longestPrefixMatch('8.8.8.8',demoRoutes)?.route.prefix).toBe(0));
});
