import type { NetworkLink, NetworkNode, Scenario } from '../sim/types';
export const nodes:NetworkNode[]=[
 {id:'client',label:'Maya’s laptop',kind:'client',location:'Toronto · Canada',ip:'192.0.2.10',description:'Browser process requesting Chloe’s performance dashboard.'},
 {id:'gateway',label:'Home gateway',kind:'gateway',location:'Toronto · access network',ip:'192.0.2.1',description:'Default gateway; forwards the datagram to the provider network.'},
 {id:'isp',label:'ISP edge router',kind:'router',location:'Provider backbone',ip:'198.51.100.1',description:'Performs an IP forwarding lookup and selects the next hop.'},
 {id:'resolver',label:'Recursive DNS',kind:'resolver',location:'Resolver service',ip:'203.0.113.53',description:'Answers from cache in this scenario; a cold lookup is not required.'},
 {id:'cdn',label:'CDN edge',kind:'cdn',location:'Tokyo · edge location',ip:'203.0.113.80',description:'Serves a cached dashboard response close to the venue.'},
 {id:'origin',label:'Origin service',kind:'origin',location:'Tokyo · origin region',ip:'203.0.113.100',description:'Fallback application origin for cache misses.'}
];
export const links:NetworkLink[]=[
 {id:'l1',from:'client',to:'gateway',bandwidthMbps:100,propagationMs:2,queueCapacityBytes:64000,lossRate:0},
 {id:'l2',from:'gateway',to:'isp',bandwidthMbps:50,propagationMs:8,queueCapacityBytes:96000,lossRate:0},
 {id:'l3',from:'isp',to:'cdn',bandwidthMbps:20,propagationMs:92,queueCapacityBytes:128000,lossRate:0},
 {id:'l4',from:'cdn',to:'origin',bandwidthMbps:100,propagationMs:12,queueCapacityBytes:128000,lossRate:0}
];
export const scenarios:Scenario[]=[
 {id:'first-request',title:'The first request',subtitle:'A cold evening in Toronto',seed:4172,packetBytes:1400,protocol:'TCP + TLS 1.3 + HTTP/2',fault:'none',description:'Follow a browser request through DNS cache, local forwarding, transport setup, TLS, and an HTTP response.'},
 {id:'crowded-uplink',title:'The crowded network',subtitle:'Rehearsal traffic spikes',seed:92031,packetBytes:1400,protocol:'TCP + TLS 1.3 + HTTP/2',fault:'congestion',description:'A competing bulk transfer fills the access queue. Separate serialization, propagation, and queueing delay.'},
 {id:'packet-loss',title:'A missing packet',subtitle:'The signal gets messy',seed:7731,packetBytes:1400,protocol:'QUIC + TLS 1.3 + HTTP/3',fault:'loss',description:'A seeded loss event interrupts one datagram. Inspect the trace and compare the recovery story.'},
 {id:'dns-stale',title:'The stale address',subtitle:'The venue changed its edge',seed:118,packetBytes:1400,protocol:'TCP + TLS 1.3 + HTTP/2',fault:'dns',description:'A stale cached DNS answer directs the client to an unavailable edge. Diagnose name resolution before blaming transport.'}
];
