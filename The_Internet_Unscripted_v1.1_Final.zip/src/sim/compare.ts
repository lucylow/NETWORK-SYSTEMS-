import type { Scenario } from './types';
import { runSimulation } from './engine';
export interface ProtocolComparison { label:string; protocol:Scenario['protocol']; elapsedMs:number; goodputMbps:number; lossPercent:number; delivered:number; dropped:number; caveat:string; }
/** Runs the same synthetic scenario shape with alternate teaching protocol labels. */
export function compareProtocols(base:Scenario,seed:number):ProtocolComparison[]{
  const variants:Scenario[]=[{...base,protocol:'TCP + TLS 1.3 + HTTP/2',seed},{...base,protocol:'QUIC + TLS 1.3 + HTTP/3',seed}];
  return variants.map((scenario,index)=>{const result=runSimulation(scenario);return {label:index===0?'TCP / HTTP/2':'QUIC / HTTP/3',protocol:scenario.protocol,elapsedMs:result.metrics.elapsedMs,goodputMbps:result.metrics.goodputMbps,lossPercent:result.metrics.lossPercent,delivered:result.metrics.deliveredPackets,dropped:result.metrics.droppedPackets,caveat:'The current engine shares a simplified event model; protocol-specific congestion control, stream multiplexing, ACK ranges, and recovery are not implemented.'};});
}
