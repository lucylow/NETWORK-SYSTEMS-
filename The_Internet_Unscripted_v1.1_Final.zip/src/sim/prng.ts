/** Small deterministic Mulberry32 PRNG. Never use Math.random() in protocol logic. */
export function createRng(seed:number):()=>number {
  let state = seed >>> 0;
  return () => { state += 0x6D2B79F5; let t=state; t=Math.imul(t^(t>>>15),t|1); t^=t+Math.imul(t^(t>>>7),t|61); return ((t^(t>>>14))>>>0)/4294967296; };
}
