import { links as defaultLinks, nodes } from '../data/scenarios';
import { createRng } from './prng';
import type { EventType, Metrics, NetworkLink, PacketRecord, Scenario, SimEvent, SimulationResult } from './types';

/** Deterministic, discrete-event teaching model. It is not a production network stack. */
export function runSimulation(scenario:Scenario, overrides?:Partial<NetworkLink>[]):SimulationResult {
 const rng=createRng(scenario.seed); const events:SimEvent[]=[]; const packets:PacketRecord[]=[]; let seq=0;
 const links=defaultLinks.map(l=>({...l,...(overrides?.find(o=>o.id===l.id)??{})}));
 const add=(timeMs:number,type:EventType,detail:string,extra:Partial<SimEvent>={})=>events.push({id:`e${++seq}`,timeMs,sequence:seq,type,detail,...extra});
 const packet:PacketRecord={id:'pkt-0001',source:'192.0.2.10:51514',destination:'203.0.113.80:443',bytes:scenario.packetBytes,protocol:scenario.protocol,path:[],status:'created',headers:[
  {layer:'Application',fields:{protocol:scenario.protocol.includes('HTTP/3')?'HTTP/3':'HTTP/2',method:'GET',path:'/performance/live'}},
  {layer:'Transport',fields:scenario.protocol.includes('QUIC')?{protocol:'QUIC over UDP',destinationPort:443,packetNumber:1,streamId:0}:{protocol:'TCP',sourcePort:51514,destinationPort:443,flags:'ACK',sequenceNumber:1001}},
  {layer:'Network',fields:{protocol:'IPv4',source:'192.0.2.10',destination:'203.0.113.80',ttl:64}},
  {layer:'Link',fields:{source:'02:00:00:00:00:10',destination:'02:00:00:00:00:01',type:'Ethernet'}}
 ]}; packets.push(packet); add(0,'PacketCreated','Browser creates a request packet.',{packetId:packet.id,nodeId:'client',bytes:packet.bytes});
 if(scenario.fault==='dns') { add(0,'DnsResolved','Stale cache returns 203.0.113.79; configured edge is unavailable.',{nodeId:'resolver'}); add(1,'PacketDropped','No route to the stale edge address. The failure occurs before transport setup.',{packetId:packet.id,nodeId:'isp'}); packet.status='dropped'; packet.path=['client','gateway','isp']; }
 else {
  add(0.4,'DnsResolved','Cached A/AAAA answer is returned; no root query is needed.',{nodeId:'resolver'});
  add(1.2,'Handshake',scenario.protocol.includes('QUIC')?'QUIC Initial carries TLS 1.3 handshake messages.':'TCP three-way handshake completes, followed by a TLS 1.3 handshake.',{nodeId:'client'});
  let t=2; const path=['client','gateway','isp','cdn'];
  for(let i=0;i<3;i++){
   const link=links[i]; const congestion=scenario.fault==='congestion'&&link.id==='l2';
   const queueMs=congestion?38:0; const loss=scenario.fault==='loss'&&link.id==='l3'&&rng()<0.85;
   add(t,'QueueEnqueued',`Packet enters ${link.id} queue${congestion?' behind competing bulk traffic':''}.`,{packetId:packet.id,nodeId:link.from,linkId:link.id});
   const serialization=(packet.bytes*8)/(link.bandwidthMbps*1000); const depart=t+queueMs+serialization; 
   add(depart,'PacketTransmitted',`Serialized at ${link.bandwidthMbps} Mbit/s; propagation delay is ${link.propagationMs} ms.`,{packetId:packet.id,nodeId:link.from,linkId:link.id,bytes:packet.bytes});
   if(loss){add(depart+link.propagationMs,'PacketDropped','Seeded loss model drops this datagram on the provider-to-edge link.',{packetId:packet.id,nodeId:link.to,linkId:link.id});packet.status='dropped';packet.path=path.slice(0,i+1);break;}
   t=depart+link.propagationMs; add(t,'PacketArrived',`Packet arrives at ${nodes.find(n=>n.id===link.to)?.label}.`,{packetId:packet.id,nodeId:link.to,linkId:link.id}); packet.path.push(link.to);
   if(i===0)add(t+0.1,'RouteSelected','Gateway selects the ISP next hop using its forwarding table.',{nodeId:'gateway'});
   if(i===1)add(t+0.1,'RouteSelected','ISP router applies longest-prefix match for the destination.',{nodeId:'isp'});
  }
  if(packet.status!=='dropped') {packet.status='delivered';t+=4;add(t,'ApplicationComplete','CDN edge returns the dashboard response to the application.',{nodeId:'cdn',packetId:packet.id});}
 }
 events.sort((a,b)=>a.timeMs-b.timeMs||a.sequence-b.sequence);
 const elapsed=events[events.length-1]?.timeMs??0; const delivered=packet.status==='delivered'?1:0; const dropped=packet.status==='dropped'?1:0;
 const delay=elapsed; const metrics:Metrics={elapsedMs:Number(elapsed.toFixed(2)),deliveredPackets:delivered,droppedPackets:dropped,throughputMbps:Number((delivered*packet.bytes*8/Math.max(elapsed,1)/1000).toFixed(3)),goodputMbps:Number((delivered*packet.bytes*8/Math.max(elapsed,1)/1000).toFixed(3)),lossPercent:dropped*100,averageDelayMs:Number(delay.toFixed(2)),queueDelayMs:events.some(e=>e.type==='QueueEnqueued'&&e.detail.includes('competing'))?38:0};
 const summary=delivered?'The request reached the CDN edge in this simplified model. Inspect the event trace to explain each delay component.':'The request did not complete. The event trace identifies the failure boundary; diagnose it before changing unrelated layers.';
 return {scenario,seed:scenario.seed,events,packets,metrics,success:!!delivered,summary};
}
export function calculateBdpMbpsMs(bandwidthMbps:number,rttMs:number):number { return bandwidthMbps*1_000_000*(rttMs/1000)/8/1_000_000; }
export function longestPrefixMatch<T extends {prefix:string;nextHop:string}>(ip:string,routes:T[]):T|undefined {
 const toBits=(v:string)=>v.split('.').map(Number).map(n=>n.toString(2).padStart(8,'0')).join(''); const bits=toBits(ip);
 return [...routes].filter(r=>{const [net,len]=r.prefix.split('/');return bits.startsWith(toBits(net).slice(0,Number(len)));}).sort((a,b)=>Number(b.prefix.split('/')[1])-Number(a.prefix.split('/')[1]))[0];
}
