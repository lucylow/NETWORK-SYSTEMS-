export type NodeKind = 'client'|'gateway'|'router'|'resolver'|'cdn'|'origin';
export interface NetworkNode { id:string; label:string; kind:NodeKind; location:string; ip:string; description:string; }
export interface NetworkLink { id:string; from:string; to:string; bandwidthMbps:number; propagationMs:number; queueCapacityBytes:number; lossRate:number; }
export interface Scenario { id:string; title:string; subtitle:string; seed:number; packetBytes:number; protocol:'TCP + TLS 1.3 + HTTP/2'|'QUIC + TLS 1.3 + HTTP/3'; fault:'none'|'congestion'|'loss'|'dns'; description:string; }
export type EventType = 'PacketCreated'|'QueueEnqueued'|'PacketTransmitted'|'PacketArrived'|'PacketDropped'|'RouteSelected'|'DnsResolved'|'Handshake'|'ApplicationComplete';
export interface SimEvent { id:string; timeMs:number; sequence:number; type:EventType; packetId?:string; nodeId?:string; linkId?:string; detail:string; bytes?:number; }
export interface PacketRecord { id:string; source:string; destination:string; bytes:number; protocol:string; status:'created'|'queued'|'in-flight'|'delivered'|'dropped'; path:string[]; headers:{layer:string;fields:Record<string,string|number>}[]; }
export interface Metrics { elapsedMs:number; deliveredPackets:number; droppedPackets:number; throughputMbps:number; goodputMbps:number; lossPercent:number; averageDelayMs:number; queueDelayMs:number; }
export interface SimulationResult { scenario:Scenario; seed:number; events:SimEvent[]; packets:PacketRecord[]; metrics:Metrics; success:boolean; summary:string; }
