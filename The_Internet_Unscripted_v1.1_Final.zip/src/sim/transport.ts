/** Simplified Reno-style congestion-window teaching model; not a TCP stack. */
export interface CwndRound { round:number; cwnd:number; ssthresh:number; phase:'slow-start'|'congestion-avoidance'|'fast-recovery'|'timeout'; sentSegments:number; acknowledged:number; lost:boolean; note:string; }
export interface CwndConfig { initialCwnd:number; initialSsthresh:number; rounds:number; lossRound:number; lossKind:'triple-duplicate-ack'|'timeout'|'none'; }
export function simulateCwnd(config: CwndConfig): CwndRound[] {
  const rounds=Math.max(1,Math.min(30,Math.floor(config.rounds))); let cwnd=Math.max(1,config.initialCwnd); let ssthresh=Math.max(2,config.initialSsthresh); let phase:CwndRound['phase']=cwnd<ssthresh?'slow-start':'congestion-avoidance'; const rows:CwndRound[]=[];
  for(let round=1;round<=rounds;round++){
    const lost=config.lossKind!=='none'&&round===config.lossRound; const sent=Math.max(1,Math.floor(cwnd));
    if(lost){
      if(config.lossKind==='timeout'){ssthresh=Math.max(2,Math.floor(cwnd/2));cwnd=1;phase='timeout';rows.push({round,cwnd,ssthresh,phase,sentSegments:sent,acknowledged:Math.max(0,sent-1),lost:true,note:'Retransmission timeout: reset cwnd to one MSS and restart slow start.'});}
      else {ssthresh=Math.max(2,Math.floor(cwnd/2));cwnd=ssthresh+3;phase='fast-recovery';rows.push({round,cwnd,ssthresh,phase,sentSegments:sent,acknowledged:Math.max(0,sent-1),lost:true,note:'Three duplicate ACKs: halve the threshold and enter fast recovery.'});}
      continue;
    }
    const before=cwnd; const note=phase==='slow-start'?'ACKs grow cwnd approximately exponentially (one MSS per ACK).':phase==='fast-recovery'?'Recovery completes; deflate cwnd to ssthresh.':'Congestion avoidance grows cwnd approximately one MSS per RTT.';
    if(phase==='fast-recovery'){cwnd=ssthresh;phase='congestion-avoidance';}
    else if(cwnd<ssthresh){cwnd=cwnd*2;phase=cwnd>=ssthresh?'congestion-avoidance':'slow-start';}
    else {cwnd=cwnd+1;phase='congestion-avoidance';}
    rows.push({round,cwnd:before,ssthresh,phase:phase==='congestion-avoidance'&&before<ssthresh?'slow-start':phase,sentSegments:sent,acknowledged:sent,lost:false,note});
  }
  return rows;
}
export function bandwidthDelayProductBytes(bandwidthMbps:number,rttMs:number):number{return Math.max(0,bandwidthMbps)*1_000_000/8*(Math.max(0,rttMs)/1000);}
