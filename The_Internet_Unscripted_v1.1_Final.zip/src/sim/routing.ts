/** Pure IPv4 subnet and longest-prefix-match utilities for the Routing Studio. */
export interface RouteEntry { destination: string; prefix: number; nextHop: string; interfaceName: string; metric: number; source: 'connected'|'static'|'bgp'; }
export interface RouteMatch { route: RouteEntry; matchedAddress: string; prefixLength: number; networkAddress: string; broadcastAddress: string; }

export function ipv4ToInt(input: string): number {
  const parts = input.trim().split('.');
  if (parts.length !== 4 || parts.some(p => !/^\d{1,3}$/.test(p) || Number(p) > 255)) throw new Error(`Invalid IPv4 address: ${input}`);
  return parts.reduce((acc, part) => ((acc << 8) | Number(part)) >>> 0, 0);
}
export function intToIpv4(value: number): string {
  return [24,16,8,0].map(shift => (value >>> shift) & 255).join('.');
}
export function prefixMask(prefix: number): number {
  if (!Number.isInteger(prefix) || prefix < 0 || prefix > 32) throw new Error('Prefix must be an integer from 0 to 32');
  return prefix === 0 ? 0 : (0xffffffff << (32-prefix)) >>> 0;
}
export function subnetDetails(address: string, prefix: number) {
  const ip = ipv4ToInt(address); const mask = prefixMask(prefix); const network = (ip & mask) >>> 0;
  const broadcast = (network | (~mask >>> 0)) >>> 0; const total = 2 ** (32-prefix);
  const usable = prefix >= 31 ? (prefix === 31 ? 2 : 1) : Math.max(0,total-2);
  return { address, prefix, cidr: `${intToIpv4(network)}/${prefix}`, mask: intToIpv4(mask), network: intToIpv4(network), broadcast: intToIpv4(broadcast), firstHost: prefix >= 31 ? intToIpv4(network) : intToIpv4(network+1), lastHost: prefix >= 31 ? intToIpv4(broadcast) : intToIpv4(broadcast-1), totalAddresses: total, usableHosts: usable, wildcard: intToIpv4((~mask) >>> 0) };
}
export function isInPrefix(address: string, destination: string, prefix: number): boolean {
  const mask = prefixMask(prefix); return (ipv4ToInt(address) & mask) === (ipv4ToInt(destination) & mask);
}
export function longestPrefixMatch(address: string, routes: RouteEntry[]): RouteMatch | null {
  const matches = routes.filter(route => isInPrefix(address, route.destination, route.prefix));
  if (!matches.length) return null;
  matches.sort((a,b) => b.prefix-a.prefix || a.metric-b.metric);
  const route = matches[0]; const details = subnetDetails(route.destination, route.prefix);
  return { route, matchedAddress: address, prefixLength: route.prefix, networkAddress: details.network, broadcastAddress: details.broadcast };
}
export const demoRoutes: RouteEntry[] = [
  {destination:'0.0.0.0',prefix:0,nextHop:'198.51.100.254',interfaceName:'wan0',metric:100,source:'static'},
  {destination:'10.0.0.0',prefix:8,nextHop:'10.255.0.1',interfaceName:'core0',metric:20,source:'bgp'},
  {destination:'10.1.0.0',prefix:16,nextHop:'10.1.255.1',interfaceName:'edge1',metric:10,source:'static'},
  {destination:'10.1.4.0',prefix:24,nextHop:'direct',interfaceName:'vlan40',metric:0,source:'connected'},
  {destination:'172.16.0.0',prefix:12,nextHop:'172.16.0.1',interfaceName:'vpn0',metric:5,source:'static'},
  {destination:'192.0.2.0',prefix:24,nextHop:'direct',interfaceName:'lan0',metric:0,source:'connected'}
];
