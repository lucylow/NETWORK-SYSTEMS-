# The Internet, Unscripted — Maya & Chloe’s World Tour

A Replit-ready React + TypeScript + Vite prototype based on the uploaded 357-page build blueprint. It pairs a pastel Y2K scrapbook narrative with a graduate-level networking lab.

## Run on Replit
1. Create a new **Node.js** Repl.
2. Upload this ZIP and extract it (or import the repository after pushing it to GitHub).
3. In the Shell, run `npm install`.
4. Run `npm run dev -- --host 0.0.0.0` (or click Run; the included `.replit` config uses this command).
5. Open the web preview.

Requires Node.js `^20.19.0 || >=22.12.0`.

## Local development
```bash
npm install
npm run dev
npm test
npm run build
```

## Included in this prototype
- Responsive Story, Protocol Lab, Packet Inspector, Routing Studio, Transport Lab, Compare Protocols, Research Notebook, and Reference Library views.
- Four seeded mock incidents: baseline request, congestion, packet loss, and stale DNS cache.
- Standalone deterministic TypeScript simulation engine with virtual timestamps and stable event ordering.
- Illustrative Toronto-to-Tokyo topology: client, gateway, ISP router, resolver, CDN edge, and origin.
- Packet metadata inspector, synthetic event timeline, metrics, JSON trace export, and local research-note persistence.
- Graduate-level concept notes for DNS, IP forwarding, TCP/TLS, QUIC/HTTP/3, and queueing.
- Routing Studio: IPv4 validation, subnet masks, CIDR boundaries, wildcard masks, usable-host counts, and longest-prefix-match forwarding against a mock route table.
- Transport Lab: configurable Reno-style congestion-window rounds, slow-start / congestion-avoidance teaching phases, duplicate-ACK vs timeout response, and bandwidth-delay product calculator.
- Compare Protocols: paired TCP/HTTP2 and QUIC/HTTP3-labelled runs with explicit disclosure that the current core engine does not implement protocol-specific transport behaviour.
- Additional unit tests for IPv4 utilities, subnet calculations, route selection, BDP, and congestion-window response.

## Important fidelity boundary
This is a **local educational simulation**, not a production TCP/IP implementation, packet capture, live Internet measurement, or real network scanner. The baseline path and failure models are deliberately simplified. The TCP/TLS and QUIC handshake are represented as teaching events; cryptographic operations and standards-compliant wire encodings are not implemented. The congestion scenario injects a fixed queue-delay approximation. The loss scenario uses seeded randomness. No external traffic is sent.

## Project map
```text
src/
  App.tsx                 Main responsive application and views
  data/scenarios.ts       Mock nodes, links, and seeded incidents
  data/lessons.ts         Lesson cards and glossary content
  sim/types.ts            Domain types
  sim/prng.ts             Seeded pseudo-random generator
  sim/engine.ts           Discrete-event teaching simulator
  styles.css              Y2K scrapbook design system and responsive styles
tests/engine.test.ts      Determinism and core model tests
```

## v1.1 fidelity notes
- The route table is a synthetic static dataset. It does not run BGP, OSPF, IS-IS, RIB/FIB synchronization, ECMP, policy routing, or hardware forwarding.
- The subnet calculator implements IPv4 arithmetic only; it does not cover IPv6, DHCP, SLAAC, NAT, ACLs, or special-purpose address validation.
- The congestion-window chart is a deliberately simplified Reno-style conceptual model. It is not a TCP state machine or packet-level simulator.
- The comparison harness currently compares the same underlying event engine with alternate protocol labels. It intentionally does not claim measured TCP-vs-QUIC performance.

## Next vertical slices
1. Replace the fixed route with a validated topology graph and event-driven forwarding table.
2. Add byte-accurate queue serialization, per-link queue state, MTU handling, and multi-packet flows.
3. Implement explicit TCP state transitions, sequence/ACK ranges, retransmission timers, rwnd/cwnd, and documented congestion-control teaching profiles.
4. Add protocol-specific DNS cache records, ARP/NDP, DHCP/SLAAC, BGP policy, RPKI origin validation, and QUIC stream/recovery models.
5. Add versioned scenario schemas, import validation, trace replay, CSV metrics export, and accessibility review.

## Design principle
Story choices affect optional dialogue only. They never change protocol behaviour. A technical claim should be supported by a model rule, trace event, equation, or identified standard, and every simplification should be disclosed.
