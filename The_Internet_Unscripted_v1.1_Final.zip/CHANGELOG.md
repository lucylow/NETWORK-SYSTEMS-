# Changelog

## Build toolchain refresh
- Updated Vite, Vitest, and the React Vite plugin to versions accepted by the current package security policy.
- Added a lockfile and documented the supported Node.js versions.

## 1.1.0 — Graduate networking lab expansion

### Added
- Routing Studio with IPv4 parsing, CIDR subnet arithmetic, subnet/wildcard masks, network and broadcast boundaries, host counts, and longest-prefix-match route selection.
- A six-entry mock forwarding table with connected, static, BGP-labelled, and default routes.
- Transport Lab with configurable initial congestion window, slow-start threshold, round count, loss round, and duplicate-ACK / timeout / no-loss teaching profiles.
- Bandwidth-delay product calculator with byte-based result.
- Compare Protocols view with repeatable TCP/HTTP2 and QUIC/HTTP3-labelled runs and JSON export.
- Unit tests for IPv4 arithmetic, subnet calculations, route matching, BDP, and congestion-window response.

### Clarified boundaries
- The comparison harness currently reuses the same simplified event engine for both labels; it does not implement actual TCP-vs-QUIC performance differences.
- The Reno-style chart is a conceptual model, not a packet-level TCP state machine.
- Routing data is synthetic and does not implement a routing protocol.
